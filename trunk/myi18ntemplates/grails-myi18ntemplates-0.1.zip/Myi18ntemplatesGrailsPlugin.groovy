
class Myi18ntemplatesGrailsPlugin {
    def version = 0.1
    def dependsOn = [:]
	def author = "Domingo Suarez Torres"
	def authorEmail = "domingo.suarez@gmail.com"
	def title = "My I18n Templates"
	def description = "This plugin offers i18n scaffolding templates to generate a full internationalizable application."
	def documentation = "http://code.google.com/p/myi18ntemplates/wiki/Plugin"
}
